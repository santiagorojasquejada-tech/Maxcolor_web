<?php
// Configuraci?n local de XAMPP. No publiques este archivo.
return [
    'host' => '127.0.0.1',
    'database' => 'maxcolor_web',
    'username' => 'root',
    'password' => '',
    'public_url' => 'http://localhost/ho%20(1)/ho',
    'whatsapp_token' => '',
    'whatsapp_phone_id' => '',
    'whatsapp_to' => '',
    'whatsapp_graph_version' => '',
    'whatsapp_template' => 'quote_notification',
    'whatsapp_language' => 'es_CO',
];
